(function($) {

	$(function() {

		$('table').wrap('<div class="table-wrapper"></div>');

		var IsMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
			$body = $(document.body),
        	$html = $(document.documentElement),
        	$win = $(window),
			$doc = $(document);
			
		s3From.initForms(".form_block", function() {
			callDate();
		});
			
		function callDate() {
			$.datepicker.setDefaults( $.datepicker.regional[ "ru" ] );
			$( ".datepicker" ).datepicker({
				dateFormat: 'dd.mm.yy',
    			minDate: new Date(),
    			changeMonth: true,
    			changeYear: true,
    			dayNames: ["Воскрес.", "Понедел.", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"],
				monthNames: ["Января,","Февраля,","Марта,","Апреля,","Мая,","Июня,","Июля,","Августа,","Сентября,","Октября,","Ноября,","Декабря,"],
				monthNamesShort: ["Января","Февраля","Марта","Апреля","Мая","Июня","Июля","Августа","Сентября","Октября","Ноября","Декабря"],
				monthNamesTitle: ["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"],
				dayNamesShort: ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"],
				dayNamesMin: ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"]
			});
		}
		callDate();


		$(".menu-top li a").append("<span class='my_span'></span>");
		
		$(".menu-top ul").each(function(index, el) {
			$(el).closest("li").find("> a > .my_span").on("click", function(event) {
				$(this).closest("li").toggleClass("opened_level");
				event.preventDefault();
				//return false;
			});
		});

		$('.menu-top li a').on('click', function() {
            if ($(this).hasClass('s3-menu-allin-open')) {
                document.location.href = $(this).attr('href');
            };
        });
        
        $(document).on('click touchstart', function(my_event){
            if($(my_event.target).closest('.menu-top ul').length) 
              return;
            $('.menu-top li a').removeClass('s3-menu-allin-open');
		    $('.menu-top ul').removeAttr('style');
        });
		
		$('.menu-button').on('click', function(menu){
			$('.menu-scroll').addClass('opened');
			$('html, body').addClass('overflowHidden');
		});
		
		$('.menu_close span').on('click', function(menu2){
			$('.menu-scroll').removeClass('opened');
			$('html, body').removeClass('overflowHidden');
		});
		
		$(document).on('click touchstart', function(menu){
		    if( $(menu.target).closest('.menu-button').length || $(menu.target).closest('.menu-scroll').length ) 
		      return;
		    $('.menu-scroll').removeClass('opened');
			$('html, body').removeClass('overflowHidden');
		});
		
		function menuWidth() {
		    var winWidth = $(window).width();

		    if (winWidth > 1023 && $('.menuTopWrapper__menuTop').length ) {

		        var width_li = 0,
		        	countLi = 0,
		            menuTWidth = $('.menuTopWrapper .menuTopWrapper__menuTop').outerWidth();

		        $('.menuTopWrapper .menuTopWrapper__menuTop > li').each(function() {
		            width_li += Math.ceil($(this).outerWidth());
		            countLi++;
		        });
		        
		        width_li += 40;
		
		        if (menuTWidth < width_li) {

		            $('.menuTopWrapper .menuTopWrapper__menuTop').append("<li class='last-childrens s3-menu-allin-has'><a href='javascript:void(0);'>...</a><ul class='level-2'></ul></li>");

		            width_li += $('.menuTopWrapper .menuTopWrapper__menuTop > li.last-childrens').outerWidth();

		            for (var i = countLi-1; menuTWidth < width_li; i--) {
		                width_li -= $('.menuTopWrapper .menuTopWrapper__menuTop > li:not(last-childrens)').eq(i).outerWidth();
		                $('.menuTopWrapper .menuTopWrapper__menuTop > li.last-childrens > ul').prepend($('.menuTopWrapper .menuTopWrapper__menuTop > li:not(last-childrens)').eq(i));    
		            }
		            $('.menuTopWrapper .menuTopWrapper__menuTop').removeAttr('style');
		
		        }        
		    } else {
		        $('.menuTopWrapper .menuTopWrapper__menuTop > li').removeAttr('style');
		    }
		}
		
        $(window).load(function() {
		 	menuWidth();
			$('.menuTopWrapper__menuTop').s3MenuAllIn({
		        type: 'bottom',
		        showTime: 250,
		        hideTime: 250
		    }); 

		});
		
		$('.menu-top').on('click', 'li.has > a .my_span', function(clArr) {
            var $this = $(this).closest('li');
            $this.find('>a').parents('ul:first').find('>li.opened_level').not($this).find('>ul').slideUp(0, function() {
                $this.find('>a').parents('ul:first').find('>li.opened_level').not($this).removeClass('opened_level');
            });
        });
		

		$('.topslider').addClass('owl-carousel').owlCarousel({
	        nav: false,
	        items: 1,
	        loop: true,
	        dots: true,
	        autoplay: true,
	        autoplayTimeout: 5000,
	        smartSpeed: 500,
	        animateOut: 'fadeOut',
	        dotsContainer: '#customDots'
	    });


		$('.rev_slid').owlCarousel({
	        nav: true,
	        items: 1,
	        loop: true,
	        dots: false,
	        //margin: 80
	    });

	    var menu_slid_owl;
	    var photo_block_owl;

	    $.resizeController([1023], function() {

	    	if ( ! $('.menu_slid').data('owlCarousel') ) {
    			menu_slid_owl = $('.menu_slid').addClass('owl-carousel').owlCarousel({
    		        nav: true,
    		        loop: true,
    		        dots: false,
    		        margin: 0,
    		        items: 1
    		    });
	    	}
			
	    	if ( ! $('.photo_block').data('owlCarousel') ) {

    		    photo_block_owl = $('.photo_block').addClass('owl-carousel').owlCarousel({
    		        nav: true,
    		        items: 3,
    		        loop: true,
    		        dots: false,
    		        margin: 3,
    		        responsiveClass: true,
    		        responsive: {

    			       	0:{
    			            items:2
    			        },
    			        479:{
    			            items:3
    			        },
    			        480:{
    			            items:3
    			        },
    			        767:{
    			            items:3
    			        },
    			        768:{
    			            items:3
    			        },
    			        1023:{
    			            items:4
    			        }
    		        }
    		    });

	    	}

		}, function() {
			
			if ( $('.menu_slid.owl-carousel').length ) {
				$('.menu_slid').removeClass('owl-carousel')
				menu_slid_owl.trigger('destroy.owl.carousel');
			}

			if ( $('.photo_block.owl-carousel').length ) {
				$('.photo_block').removeClass('photo_block')
				photo_block_owl.trigger('destroy.owl.carousel');
			}

		});


		$('.form_but').on('click', function(){
	    	if ($('.form_but').hasClass('opened')) {
				$html.removeClass('overflowHiddenForm');
				$(window).scrollTop($pos);
	    	} else {
	    		$pos = $(window).scrollTop();
		    	$('.form_block').addClass('opened');	
		    	$html.addClass('overflowHiddenForm');
	    	}
	    });
	    
	    $('.form_block .close').on("click", function(event){
                $('.form_block').removeClass('opened');
                $html.removeClass('overflowHiddenForm');
                $(window).scrollTop($pos);
        }); 
	    
		$body.on("click touchstart", function(event){
            if ($(event.target).closest($('.form_but').add($('.form_block .form_in, #ui-datepicker-div'))).length) return;
            if ($('.form_block').hasClass('opened')) {
                $('.form_block').removeClass('opened');
                $html.removeClass('overflowHiddenForm');
                $(window).scrollTop($pos);
            }
        }); 
		
	   	
        $body.on('keyup', function(event){
            if (event.keyCode == 27 && $('.form_block').hasClass("opened")) {
                $('.form_block').removeClass("opened");
                $html.removeClass('overflowHiddenForm');
                $(window).scrollTop($pos);
                
            }
        });
        
        if (IsMobile) {
        	$('.top_block ').addClass('responsive');
        	$('.menuTopWrapper ').addClass('responsive');
        	$('.site-header__address').addClass('responsive');
        	$('.cont_block').addClass('responsive');
        	$('.menu-button').addClass('responsive');
        	
        } else {
        	$('.top_block ').removeClass('responsive');
        	$('.menuTopWrapper ').removeClass('responsive');
        	$('.site-header__address').removeClass('responsive');
        	$('.cont_block').removeClass('responsive');
        	$('.menu-button').removeClass('responsive');
        };
        
        
        var gal = $('.photo_block');
        
        gal.lightGallery({
            selector: '.photo_item',
            thumbnail: false
        })
        

	});

})(jQuery);